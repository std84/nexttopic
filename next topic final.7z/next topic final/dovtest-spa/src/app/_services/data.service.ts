import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Currency } from '../_modals/Currency';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  baseurl = environment.apiurl + 'Currency/';
  datas = [];
  role = 'admin';
  constructor(private http: HttpClient) { }
  getData(): Observable<Currency[]> {
     return this.http.get<Currency[]>(this.baseurl ) ;
     // return of(this.datas);
  }
  getDataFromApi(): Observable<object>  {
    return this.http.get<object>('https://data.messari.io/api/v1/assets?fields=id,slug,symbol,metrics/market_data/price_usd' ) ;
  }
}
