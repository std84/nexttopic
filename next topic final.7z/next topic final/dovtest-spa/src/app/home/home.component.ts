import { Component, OnInit } from '@angular/core';
import { Currency } from '../_modals/Currency';
import { DataService } from '../_services/data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  datas: Currency[];
  curData: Currency;
  tmp: object;
  curType: any;
  amount: any;

  constructor(private dataService: DataService, private route: ActivatedRoute, private router: Router  ) {

  }

  ngOnInit() {
     this.curType = "Price";
  }
  Submit() {
    // COMMENT: למרות שיש אפשרות לעשות את זה בצד השרת בגלל אילוצי זמן זה נעשה פה
    this.dataService.getData().subscribe(res => {
      if(this.amount > 0){
        this.datas = res.slice(0, this.amount);
      } else {
        this.datas = res;
      }
      if (this.curType === 'Price') {
        this.datas.sort(function (a, b) {
          return b.price - a.price;
        });
      } else {
        this.datas.sort(function (a, b) {
          return b.marketCap - a.marketCap;
        });
      }
      // COMMENT: גרסת אנגולר בלבד
   /* this.dataService.getDataFromApi().subscribe(res => {
       if(this.amount > 0){
        this.datas = res.slice(0, this.amount);
      } else {
        this.datas = res;
      }
      if(this.curType === "price") {
        this.datas.sort(function (a, b) {
          return b.metrics.market_data.price_usd - a.metrics.market_data.price_usd;
        });
      }else {
        this.datas.sort(function (a, b) {
          return b.metrics.current_marketcap_usd - a.metrics.current_marketcap_usd;
        });*/
    });
  }


}
