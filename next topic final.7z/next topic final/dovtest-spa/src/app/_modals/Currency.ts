export interface Currency {
    coinName: string;
    symbol: string;
    price: any;
    marketCap: any;

}
