export interface ApiCurrency {
    id: string;
    metrics: {
        market_data: {
            price_usd: number;
        };
        marketcap: {
            current_marketcap_usd: any;
          }
    };
    slug: string;
    symbol: string;


}
