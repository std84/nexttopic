namespace dovtest.MODAL
{
    public class ApiCurrency
    {  
    public  metrics metrics { get; set; }
   public string  name { get; set; }
    public string  symbol { get; set; }
    }
}