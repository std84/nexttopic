namespace dovtest.MODAL
{
    public class ApiMarketData
    {
        public string price_usd { get; set;}
    }
}