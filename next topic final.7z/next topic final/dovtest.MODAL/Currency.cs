namespace dovtest.MODAL
{
    public class Currency
    {
           
           
        public string coinName { get; set; }
        public string symbol { get; set; }
        public string price { get; set; }
        public string marketCap { get; set; }

        
    }
}