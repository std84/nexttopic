using System.Collections.Generic;

namespace dovtest.MODAL
{
    public class ApiResponse
    {
         public object status { get; set; }
        public List<ApiCurrency> data { get; set; }
    }
}