namespace dovtest.MODAL
{
    public class ApiMarketCap
    {
        public string current_marketcap_usd { get; set;}
    }
}