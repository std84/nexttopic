namespace dovtest.MODAL
{
    public class metrics
    {
        
       public ApiMarketCap marketcap { get; set; }
   public ApiMarketData  market_data  { get; set; }
    }
}