using System.Collections.Generic;
using System.Threading.Tasks;
using dovtest.MODAL;

namespace dovtest.REPOSITORY
{
    public interface IDataRepository
    {
         Task<ApiResponse> GetData();
    }
}