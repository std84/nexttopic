using System.Linq;
using AutoMapper;
using dovtest.MODAL;

namespace dovtest.REPOSITORY
{
    public class AutoMapperProfiles: Profile
    {
        public AutoMapperProfiles(){
  
             CreateMap<ApiCurrency, Currency>()
             .ForMember(dest => dest.coinName,  opt => {
                opt.MapFrom(src => src.name);
            })
            .ForMember(dest => dest.price,  opt => {
                opt.MapFrom(src => src.metrics.market_data.price_usd);
            })            
            .ForMember(dest => dest.marketCap,  opt => {
                opt.MapFrom(src => src.metrics.marketcap.current_marketcap_usd);
            });
           
        }
    
    }
}