using System.Threading.Tasks;
using dovtest.MODAL;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Net.Http;
using System;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using AutoMapper;
namespace dovtest.REPOSITORY
{
    public class DataRepository : IDataRepository
    {
          static HttpClient client = new HttpClient();
        public async Task<ApiResponse> GetData()
        {
            var urlpath = "https://data.messari.io/api/v1/assets?fields=name,symbol,metrics/market_data/price_usd,metrics/marketcap/current_marketcap_usd";
            var product = new object();
            List<Currency> res = null;
            


    var client = new HttpClient();
    client.BaseAddress = new Uri(urlpath);  
    client.DefaultRequestHeaders.Accept.Clear();  
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));  
    //GET Method  
    HttpResponseMessage response = await client.GetAsync(urlpath);  
    if (response.IsSuccessStatusCode)  
    {  
        ApiResponse ds = await response.Content.ReadAsAsync <ApiResponse>();  

        return ds;
    }  
    else  
    {  
         Console.WriteLine("Internal server Error");  
        return null;
       
    }  



 
        }
    }
}