using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using dovtest.REPOSITORY;
using dovtest.MODAL;
using AutoMapper;
namespace dovtest.API.Controllers
{
     [ApiController]
    [Route("[controller]")]
    public class CurrencyController: ControllerBase
    {
         private readonly IDataRepository _repo;
            private readonly IMapper _mapper;
        public CurrencyController(IDataRepository repo, IMapper mapper){
            _repo= repo;
            _mapper = mapper;
        }
          [HttpGet]
        public async Task<IActionResult> Get()
        {
          // comments: היו הסתבכויות עם קבלת נתונים מהשרת לכן יש הרבה ENTITES במיפוי
          var data = await _repo.GetData();
           var res = _mapper.Map<IList<Currency>>(data.data);
             return Ok(res);
         
        }
    }
}